from pyray import *
from constants import *
from tile_system import new_board
from start_settings import *
import assets

def display_start_screen(game_state, counter):
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    start_rect = (59 + 90, 214 + 60, 304,130)
    settings_rect = (1035, 615, 220,70)
    flame_counter = counter % 80
    draw_texture_pro(assets.START_BG[counter//20], (0,0,assets.START_BG[counter//20].width, assets.START_BG[counter//20].height),
                     (0,0,1280,720), (0,0), 0.0, WHITE)
    #draw_texture_ex(assets.FLAME[flame_counter//20], (720, 360), 0.0, 2.2, WHITE)
    #draw_rectangle_rec(start_rect, BLUE) #debug purposws
    draw_texture_ex(assets.LOGO, (75 - 100, 51 - 100), 0.0, 1.0, WHITE)
    draw_texture_ex(assets.START, (59, 214), 0.0, 1.0, WHITE)
    #draw_rectangle_rec(settings_rect, RED)
    draw_texture_ex(assets.SETTINGS_BUTTON, (1045 - 65, 615 - 50), 0.0, 1.0, WHITE)
    if "instructions" in game_state:
                game_state = display_instructions(game_state)
    elif "settings" in game_state:
            game_state = display_settings(game_state)
    elif check_collision_point_rec((mouse_x, mouse_y), start_rect) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        new_board(1)
        game_state = "game"
    elif check_collision_point_rec((mouse_x, mouse_y), settings_rect) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "start_settings"
    counter += 1
    if counter > 399:
        return game_state, 0
    return game_state, counter