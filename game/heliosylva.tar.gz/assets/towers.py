from pyray import *
import constants
import game_engine

#Range of Ladybugs, 1
#Range of Bee, 2
middle = [(1,-1), (-1,1)]

left = [(-1,-1), (0, -1), (-1,0), (-1,-2), (0, -2), (1,-2),(-2,-1), (-2, 0), (-2,1)]

right = [(1, 0), (0, 1), (1,1), (-1,2), (0, 2), (1,2), (2,-1), (2, 0), (2,1)]

range_of_one = [(-1,-1), (0, -1), (1,-1), 
                (-1,0), (1, 0),
                (-1,1), (0, 1), (1,1)]
range_of_two = [(-1,-2), (0, -2), (1,-2), 
                (-1,2), (0, 2), (1,2),
                (-2,-1), (-2, 0), (-2,1),
                (2,-1), (2, 0), (2,1)]

class Tower():
    def __init__(self, tower_type, loc):
        self.name = tower_type
        self.x, self.y = loc[0], loc[1]
        self.state = "idle"
        self.animation = 0
        self.attacked = False
        self.look_to = 1 #1 is right, -1 is left
        self.attack_zone = []
        if tower_type == "ladybug":
            self.attack_zone += range_of_one
            self.damage = 4
            self.max_cooldown = 1
            self.cooldown = self.max_cooldown
            
        elif tower_type == "bee":
            self.attack_zone += range_of_one + range_of_two
            self.damage = 10
            self.max_cooldown = 2
            self.cooldown = self.max_cooldown
    
    def attack(self):
        if len(game_engine.MOBS) > 0:
            first_mob = game_engine.MOBS[0].curr
            for dir_x, dir_y in middle:
                if first_mob == (self.x + dir_x, self.y + dir_y) and len(game_engine.MOBS[0].path) > 0:
                    first_mob = game_engine.MOBS[0].path[0]
                    break
            for dir_x, dir_y in right:
                if first_mob == (self.x + dir_x, self.y + dir_y):
                    self.look_to = 1
            for dir_x, dir_y in left:
                if first_mob == (self.x + dir_x, self.y + dir_y):
                    self.look_to = -1
            any_mob_detected = False
            for mob in game_engine.MOBS:
                if not self.attacked:
                    for dir_x, dir_y in self.attack_zone:
                        if mob.curr == (self.x + dir_x, self.y + dir_y) and self.cooldown <= 0:
                            self.cooldown = self.max_cooldown
                            mob.health -= self.damage
                            self.animation = 0
                            self.attacked = True
                            break
            if self.attacked:
                self.state = "attack"
        if self.attacked and self.animation >=  4 * 5 - 1:
            self.state = "idle"
            self.attacked = False
            self.animation = 0
        elif self.animation >=  4 * 10 - 1:
            self.animation = 0
        else:
            self.animation += 1
        self.cooldown -= 0.01667 if self.cooldown > 0 else 0
        