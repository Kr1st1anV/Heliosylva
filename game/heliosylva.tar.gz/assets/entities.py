from pyray import *
import assets
from constants import *
#Takes 5 seconds at speed 1

class Entities():
    def __init__(self, path, mob_type="worm"):
        self.name = mob_type
        self.path = path[1:]
        self.pos = Vector2(100,100)
        self.count = 0
        self.animation_count = 0
        self.curr = path[0]
        self.determine_mob(mob_type)
        
    def buy (self, branches): 
        diff = branches - self.cost
        return diff if diff >= 0 else branches
        
    def determine_mob(self, mob_type):
        if mob_type == "worm":
            self.max_health = 10
            self.health = 10
            self.speed = 3
            self.attack = 1
            self.cost = 1
            self.off_set = (6, -20)
            self.mob = assets.WORM
        elif mob_type == "butterfly":
            self.max_health = 20
            self.health = 20
            self.speed = 5
            self.attack = 5
            self.cost = 5
            self.off_set = (15,-30)
            self.mob = assets.BUTTERFLY
        elif mob_type == "beetle":
            self.max_health = 200
            self.health = 200
            self.speed = 3
            self.attack = 50
            self.cost = 50
            self.off_set = (0,-20)
            self.mob = assets.BEETLE
        elif mob_type == "snail":
            self.max_health = 100
            self.health = 100
            self.speed = 2
            self.attack = 20
            self.cost = 20
            self.off_set = (5,-15)
            self.mob = assets.SNAIL
        elif mob_type == "dragonfly":
            self.max_health = 50
            self.health = 50
            self.speed = 5
            self.attack = 10
            self.cost = 10
            self.off_set = (15,-30)
            self.mob = assets.DRAGONFLY
    
    def draw_health(self):
        flying_offset = 2
        if self.name in ["butterfly", "dragonfly"]:
            flying_offset = -8
        draw_rectangle_rec((flying_offset + GRID_X + (self.pos.y * TILE_WIDTH // 2) + (self.pos.x * TILE_WIDTH // 2) + self.off_set[0], GRID_Y - (self.pos.y * TILE_HEIGHT * 1/2) + (self.pos.x * TILE_HEIGHT // 2) + self.off_set[1]
                                    ,50, 8), RED)
        draw_rectangle_rec((flying_offset + GRID_X + (self.pos.y * TILE_WIDTH // 2) + (self.pos.x * TILE_WIDTH // 2) + self.off_set[0], GRID_Y - (self.pos.y * TILE_HEIGHT * 1/2) + (self.pos.x * TILE_HEIGHT // 2) + self.off_set[1]
                            ,(self.health/self.max_health)* 50, 8), GREEN)
        
    def move(self, tree_health, game_status):
        if self.path == []:
            tree_health -= self.attack
            return True, tree_health
        if self.animation_count // 12 == 4:
            self.animation_count = 0
        if ((self.path[0][0] - self.curr[0], self.path[0][1] - self.curr[1])) in [(1, 0), (0, 1)]:
            draw_texture_rec(self.mob[self.animation_count // 12], 
                             (0,0,self.mob[self.animation_count // 12].width, self.mob[self.animation_count // 12].height), 
                             (GRID_X + (self.pos.y * TILE_WIDTH // 2) + (self.pos.x * TILE_WIDTH // 2) + self.off_set[0], GRID_Y - (self.pos.y * TILE_HEIGHT * 1/2) + (self.pos.x * TILE_HEIGHT // 2) + self.off_set[1]),
                             WHITE)
        else:
            draw_texture_rec(self.mob[self.animation_count // 12], 
                                         (0,0,-self.mob[self.animation_count // 12].width, self.mob[self.animation_count // 12].height), 
                                         (GRID_X + (self.pos.y * TILE_WIDTH // 2) + (self.pos.x * TILE_WIDTH // 2) + self.off_set[0], GRID_Y - (self.pos.y * TILE_HEIGHT * 1/2) + (self.pos.x * TILE_HEIGHT // 2) + self.off_set[1]),
                                         WHITE)
        self.pos = vector2_lerp(self.curr, (self.path[0][0], self.path[0][1]), self.count)
        self.count += (0.03333 * self.speed / 3) * (0 if "settings" in game_status or "surrender" in game_status or "instructions" in game_status else 1)
        if self.count >= 1:
            self.curr = self.path[0]
            self.path = self.path[1:]
            self.count = 0
        self.animation_count += 1 * (0 if "settings" in game_status or "surrender" in game_status or "instructions" in game_status else 1)
        return False, tree_health
    