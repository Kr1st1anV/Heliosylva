from pyray import *
import assets
from constants import *

def hammer_animation(counter):
    pass
    # draw_texture_pro(assets.VICTORY[counter//4], (0,0,assets.VICTORY[counter//4].width, assets.VICTORY[counter//4].height),
    #                         (0,0,SCREEN_SIZE_X,SCREEN_SIZE_Y), (0,0), 0.0, WHITE)
    # if counter < 4 * 32:
    #     counter += 1
    # else:
    #     counter = 0
    # return counter

def show_custom_cursor(counter):
    draw_texture_ex(assets.HAMMER[counter], (int(get_mouse_x()), int(get_mouse_y())), 0.0, 0.0, WHITE)