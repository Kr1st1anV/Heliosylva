LEVELS = {
    # Level 1: 11 obstacles, full-board spread
    1: [[0, 0, 0, 0, "bush", 0, "bush", 'end'],
                    [0, "tree", 0, 0, 0, 0, 0, 0],
                    [0, "bush", 0, 0, 0, 0, 0, 0],
                    [0, 0, "tree", 0, 0, 0, 0, 0],
                    ["tree", 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, "tree"],
                    ['start', "bush", 0, 0, 0, 0, "tree", 0]],

    # Level 2: 11 obstacles, full-board spread
    2: [[0, "tree", 0, 0, 0, 0, "tree", 'end'],
                    [0, 0, 0, "tree", 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, "bush", 0],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    ["bush", 0, 0, "tree", 0, 0, 0, 0],
                    [0, 0, "bush", 0, 0, 0, 0, "bush"],
                    [0, 0, 0, 0, "bush", 0, 0, 0],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 3: 11 obstacles, full-board spread
    3: [[0, 0, 0, 0, 0, 0, "tree", 'end'],
                    ["bush", "bush", 0, 0, 0, 0, 0, 0],
                    [0, 0, "bush", 0, 0, "tree", 0, 0],
                    [0, 0, 0, 0, 0, 0, "bush", 0],
                    [0, 0, 0, "tree", 0, 0, 0, "bush"],
                    [0, 0, 0, 0, "tree", 0, 0, 0],
                    [0, 0, 0, "tree", 0, 0, 0, 0],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 4: 15 obstacles, full-board spread
    4: [[0, 0, 0, 0, 0, 0, "tree", 'end'],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    ["bush", "tree", "bush", "bush", "bush", 0, 0, 0],
                    [0, 0, "bush", "tree", 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    [0, 0, 0, "tree", "bush", 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, "tree", 0],
                    ['start', "bush", 0, 0, 0, 0, 0, "tree"]],

    # Level 5: 13 obstacles, full-board spread
    5: [[0, 0, 0, 0, 0, 0, "tree", 'end'],
                    [0, 0, "tree", 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, "tree", "tree", "tree"],
                    [0, 0, 0, 0, "bush", 0, 0, 0],
                    [0, 0, "ladybug", 0, "ladybug", 0, 0, 0],
                    ["tree", 0, 0, "bush", 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, "tree", 0],
                    ['start', "bush", 0, 0, 0, 0, 0, "bush"]],

    # Level 6: 12 obstacles, full-board spread
    6: [[0, 0, 0, 0, "tree", 0, "tree", 'end'],
                    [0, 0, 0, "ladybug", 0, 0, 0, 0],
                    [0, 0, 0, "tree", 0, 0, 0, "tree"],
                    [0, "tree", 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, 0],
                    ["tree", 0, "bush", 0, 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, "tree", 0, 0],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 7: 14 obstacles, full-board spread
    7: [[0, 0, 0, 0, "bush", 0, "tree", 'end'],
                    [0, 0, 0, 0, "tree", "tree", 0, 0],
                    ["tree", 0, 0, 0, "tree", 0, 0, 0],
                    [0, 0, 0, 0, "bush", 0, 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, 0],
                    [0, 0, 0, 0, "bee", 0, 0, 0],
                    [0, "tree", 0, 0, 0, 0, 0, 0],
                    ['start', "bush", "tree", 0, "tree", 0, 0, "bush"]],

    # Level 8: 13 obstacles, full-board spread
    8: [[0, 0, 0, 0, 0, 0, "tree", 'end'],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    [0, "ladybug", 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, "bush"],
                    [0, "bush", "bee", 0, "ladybug", "bush", 0, "bush"],
                    ["tree", 0, 0, "ladybug", 0, 0, 0, 0],
                    [0, 0, 0, 0, "bush", 0, 0, 0],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 9: 15 obstacles, full-board spread
    9: [[0, "bee", 0, 0, "bush", 0, "tree", 'end'],
                    [0, 0, 0, 0, "ladybug", 0, 0, 0],
                    [0, 0, "bush", 0, 0, 0, 0, 0],
                    ["tree", 0, 0, 0, "bush", 0, 0, 0],
                    [0, 0, 0, 0, "bush", 0, 0, "tree"],
                    [0, "tree", 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, "tree", "tree", "bee", 0, 0],
                    ['start', "bush", 0, 0, "tree", 0, 0, 0]],

    # Level 10: 14 obstacles, full-board spread
    10: [["bush", 0, 0, "ladybug", 0, 0, "tree", 'end'],
                    [0, 0, 0, "tree", 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, 0],
                    [0, 0, 0, "ladybug", 0, 0, 0, 0],
                    [0, 0, "tree", "tree", "tree", 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, "tree"],
                    ['start', "bush", 0, "tree", 0, "bush", 0, 0]],

    # Level 11: 14 obstacles, full-board spread
    11: [[0, 0, 0, 0, "bush", 0, "tree", 'end'],
                    ["tree", 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, "bee", 0, 0, 0],
                    [0, 0, 0, 0, "bush", 0, 0, 0],
                    [0, 0, "bush", 0, "bush", 0, 0, 0],
                    [0, 0, 0, 0, "bee", "tree", 0, 0],
                    [0, 0, 0, "bush", "bee", 0, 0, 0],
                    ['start', "bush", 0, 0, "tree", 0, 0, "bush"]],

    # Level 12: 14 obstacles, full-board spread
    12: [[0, 0, "bee", 0, "bush", 0, "tree", 'end'],
                    [0, 0, "ladybug", 0, 0, 0, 0, 0],
                    [0, 0, "ladybug", 0, 0, 0, 0, "tree"],
                    [0, 0, "bush", 0, 0, 0, 0, 0],
                    ["bush", 0, 0, "bush", 0, "bee", 0, 0],
                    [0, 0, 0, 0, 0, "tree", 0, 0],
                    [0, 0, 0, 0, 0, "ladybug", 0, 0],
                    ['start', "bush", 0, 0, 0, "bee", 0, 0]],

    # Level 13: 16 obstacles, full-board spread
    13: [[0, 0, 0, "ladybug", "bush", 0, "tree", 'end'],
                    [0, 0, 0, "ladybug", 0, 0, 0, 0],
                    [0, 0, "tree", "bush", 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, "bush", 0, "bush"],
                    [0, 0, 0, "bush", 0, "bush", 0, 0],
                    ["bush", 0, 0, 0, 0, "bush", 0, 0],
                    [0, 0, 0, 0, 0, "tree", 0, 0],
                    ['start', "bush", 0, 0, 0, "bush", 0, 0]],

    # Level 14: 13 obstacles, full-board spread
    14: [["bush", 0, 0, 0, 0, 0, "tree", 'end'],
                    [0, "tree", "bee", 0, 0, 0, 0, 0],
                    [0, 0, "bee", "ladybug", 0, 0, 0, "tree"],
                    [0, 0, 0, "bee", 0, 0, 0, 0],
                    [0, 0, 0, 0, "bee", 0, 0, 0],
                    [0, 0, 0, 0, 0, "bee", 0, 0],
                    [0, 0, "ladybug", 0, 0, 0, "tree", 0],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 15: 20 obstacles, full-board spread
    15: [[0, 0, 0, "tree", "tree", 0, "tree", 'end'],
                    [0, 0, "tree", "tree", "tree", 0, 0, 0],
                    ["bush", 0, 0, "ladybug", "ladybug", "tree", 0, 0],
                    [0, 0, 0, "ladybug", "tree", 0, 0, 0],
                    [0, 0, 0, "tree", "ladybug", 0, 0, 0],
                    [0, 0, 0, "tree", "bush", 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, "bush"],
                    ['start', "bush", 0, "tree", "tree", 0, 0, 0]],

    # Level 16: 20 obstacles, full-board spread
    16: [[0, 0, 0, 0, 0, 0, "tree", 'end'],
                    [0, "bush", 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    ["bush", 0, "bush", "bush", "bush", "bush", "tree", "bush"],
                    ["tree", 0, "bush", "bee", "bee", "bush", "tree", "bee"],
                    ["tree", 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 17: 15 obstacles, full-board spread
    17: [[0, 0, 0, "bee", 0, 0, "tree", 'end'],
                    [0, 0, 0, "ladybug", 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, 0],
                    ["ladybug", "ladybug", "ladybug", 0, "tree", "bee", "ladybug", 0],
                    [0, 0, 0, "tree", 0, 0, 0, 0],
                    [0, 0, 0, "bush", 0, 0, 0, 0],
                    [0, 0, 0, "bee", 0, 0, 0, "bush"],
                    ['start', "bush", 0, 0, 0, 0, 0, 0]],

    # Level 18: 22 obstacles, full-board spread
    18: [[0, 0, 0, "bush", "bee", 0, "tree", 'end'],
                    [0, 0, 0, "tree", "bush", 0, 0, 0],
                    ["ladybug", 0, "bee", "ladybug", "bee", 0, "ladybug", "bee"],
                    [0, 0, 0, "ladybug", "ladybug", 0, 0, 0],
                    [0, 0, 0, "bush", "bee", "tree", 0, 0],
                    [0, 0, 0, "bush", "ladybug", 0, 0, 0],
                    [0, "tree", 0, 0, 0, 0, 0, 0],
                    ['start', "bush", 0, "bee", "bush", 0, 0, 0]],

    # Level 19: 19 obstacles, full-board spread
    19: [[0, "bee", "tree", 0, 0, 0, "tree", 'end'],
                    [0, 0, "tree", 0, "tree", "bee", 0, 0],
                    [0, 0, "tree", "bush", 0, 0, 0, 0],
                    [0, 0, "bush", 0, 0, "ladybug", 0, "ladybug"],
                    ["bush", 0, "bush", 0, 0, "tree", 0, 0],
                    [0, 0, 0, 0, 0, "bush", 0, 0],
                    [0, 0, 0, 0, 0, "tree", "ladybug", 0],
                    ['start', "bush", 0, 0, 0, "bee", 0, 0]],

    # Level 20: 32 obstacles, full-board spread
    20: [["tree", 0, "tree", "bush", "bush", "ladybug", "tree", 'end'],
                    [0, 0, "bush", "tree", 0, 0, 0, 0],
                    [0, 0, "tree", "tree", 0, "ladybug", "bee", 0],
                    [0, 0, "bush", "tree", 0, "bee", "bee", 0],
                    [0, 0, "tree", "bush", 0, "ladybug", "ladybug", 0],
                    [0, 0, "tree", "bush", 0, "bee", "ladybug", 0],
                    [0, 0, 0, 0, 0, "ladybug", "bee", "tree"],
                    ['start', "bush", "bush", "bush", 0, "ladybug", "bee", 0]],

}