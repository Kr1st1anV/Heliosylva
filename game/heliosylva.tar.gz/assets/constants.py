import platform

global SCREEN_SIZE_X, SCREEN_SIZE_Y
global GRID_SIZE
global grid_layout
global ROUND_TIME
global VOLUME
global BROWN_COLOR
global SCALE, TILE_HEIGHT, TILE_WIDTH, GRID_X, GRID_Y, CLOUDS
# TILE TYPE, COLOR GRADIENT
VOLUME = 1
GRID_SIZE = 8
SCREEN_SIZE_X = 1280
SCREEN_SIZE_Y = 720
ROUND_TIME = 60
BROWN_COLOR = (69, 43, 45, 255)
SCALE = 1.9
TILE_WIDTH = 32 * SCALE
TILE_HEIGHT = 16 * SCALE
GRID_X = 200
GRID_Y = 430
CLOUDS = []
grid_layout = [[0] * GRID_SIZE for _ in range(GRID_SIZE)]
LIGHT_BROWN = (146, 98, 65, 255)
initial_clouds = True
AUDIO_OK = True

# diff_x = 0
# diff_y = 0
# if is_mouse_button_pressed(0):
#     if pt1 == ():
#         pt1 = (mouse_pos.x, mouse_pos.y)
#     elif pt2 == ():
#         pt2 = (mouse_pos.x, mouse_pos.y)
#     else:
#         diff_x = pt2[0] - pt1[0]
#         diff_y = pt2[1] - pt1[1]
#         print((pt1[0], pt1[1], diff_x, diff_y))
# if pt2 != ():
#     draw_rectangle_rec((pt1[0], pt1[1], diff_x, diff_y), RED)