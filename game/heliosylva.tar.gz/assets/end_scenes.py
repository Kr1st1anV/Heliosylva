from pyray import *
from constants import *
import assets

def end_scene(game_state, counter):
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    back_to_menu = False
    if "win" in game_state:
        draw_texture_pro(assets.VICTORY[counter//4], (0,0,assets.VICTORY[counter//4].width, assets.VICTORY[counter//4].height),
                             (0,0,SCREEN_SIZE_X,SCREEN_SIZE_Y), (0,0), 0.0, WHITE)
        if counter < 4 * 32:
            counter += 1
        else:
            back_to_menu = True
    elif "loss" in game_state:
        draw_texture_pro(assets.DEFEAT[counter//4], (0,0,assets.DEFEAT[counter//4].width, assets.DEFEAT[counter//4].height),
                                     (0,0,SCREEN_SIZE_X,SCREEN_SIZE_Y), (0,0), 0.0, WHITE)
        if counter < 4 * 26:
            counter += 1 
        else: 
            back_to_menu = True
    if back_to_menu and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "start"
    return game_state, counter