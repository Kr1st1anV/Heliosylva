from pyray import *
import assets
from constants import *

BOOK_TEXT_COLOR = (116, 63, 47, 255)

SETTINGS_RECT = (1106.0, 656.0, 132.0, 33.0)
BOOK_BTN_RECT = (910, 525, 300, 70)
SCROLLS_BTN_RECT = (910, 453, 300, 70)
PREV_SCROLL_BTN = (100, 165, 205, 435)
NEXT_SCROLL_BTN = (560, 165, 205, 435)
COOLDOWN = 1
PAGE = 0

def show_book(game_state):
    global COOLDOWN
    x = get_mouse_x()
    y = get_mouse_y()
    if "cave" in game_state:
        draw_texture_ex(assets.BOOK1, (35,95), 0, 0.6, WHITE)
    elif "island" in game_state:
        draw_texture_ex(assets.BOOK2, (35,95), 0, 0.6, WHITE)
        #print((get_mouse_x(),get_mouse_y()))
        draw_text_ex(assets.DICO_FONT, "ATK: 0\nCooldown: 0s", (243,293), 25, 0.0, BOOK_TEXT_COLOR)
        #draw_text_ex(assets.DICO_FONT, "Desc: It's just a bush.", (158,353), 25, 0.0, BOOK_TEXT_COLOR)
        draw_text_ex(assets.DICO_FONT, "           ATK: 0\nCooldown: 0s", (500,325), 25, 0.0, BOOK_TEXT_COLOR)
        #draw_text_ex(assets.DICO_FONT, "Desc: It's just a tree.", (484,385), 25, 0.0, BOOK_TEXT_COLOR)
        draw_text_ex(assets.DICO_FONT, "ATK: 4\nCooldown: 1s\nRange: 1", (243,436), 25, 0.0, BOOK_TEXT_COLOR)
        #draw_text_ex(assets.DICO_FONT, "Desc: It's cute... \n         but it bites.", (158,496), 25, 0.0, BOOK_TEXT_COLOR)
        draw_text_ex(assets.DICO_FONT, "         ATK: 10\nCooldown: 2s\n       Range 2", (484,453), 25, 0.0, BOOK_TEXT_COLOR)
        #draw_text_ex(assets.DICO_FONT, "Desc: It can sting... \nmore than once.", (483,512), 25, 0.0, BOOK_TEXT_COLOR)
    if COOLDOWN > 0:
        COOLDOWN -= 0.06667
    else:
        COOLDOWN = 0
    if check_collision_point_rec((x, y), BOOK_BTN_RECT) and is_mouse_button_down(0) and COOLDOWN == 0:
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game"
        COOLDOWN = 1
    elif check_collision_point_rec((x, y), SCROLLS_BTN_RECT) and is_mouse_button_down(0) and COOLDOWN == 0:
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game_island_scrolls"
        COOLDOWN = 1
    elif check_collision_point_rec((x, y), SETTINGS_RECT) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        COOLDOWN = 1
        game_state = "game_island_settings"
    return game_state

def show_scrolls(game_state):
    global COOLDOWN, PAGE
    x = get_mouse_x()
    y = get_mouse_y()
    if "cave" in game_state:
        draw_texture_ex(assets.ISLAND_SCROLLS[PAGE], (75,90), 0, 0.9, WHITE)
    elif "island" in game_state:
        draw_texture_ex(assets.ISLAND_SCROLLS[PAGE], (75,90), 0, 0.9, WHITE)
    if COOLDOWN > 0:
        COOLDOWN -= 0.06667
    else:
        COOLDOWN = 0
    if check_collision_point_rec((x, y), NEXT_SCROLL_BTN) and is_mouse_button_down(0) and COOLDOWN == 0:
        if PAGE < 4:
            if AUDIO_OK:
                play_sound(assets.CLICK_SOUND)
            PAGE += 1
        COOLDOWN = 1
    elif check_collision_point_rec((x, y), PREV_SCROLL_BTN) and is_mouse_button_down(0) and COOLDOWN == 0:
        if PAGE > 0:
            if AUDIO_OK:
                play_sound(assets.CLICK_SOUND)
            PAGE -= 1
        COOLDOWN = 1
    if check_collision_point_rec((x, y), SCROLLS_BTN_RECT) and is_mouse_button_down(0) and COOLDOWN == 0:
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game"
        COOLDOWN = 1
    elif check_collision_point_rec((x, y), BOOK_BTN_RECT) and is_mouse_button_down(0) and COOLDOWN == 0:
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game_island_book"
        COOLDOWN = 1
    elif check_collision_point_rec((x, y), SETTINGS_RECT) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game_island_settings"
        COOLDOWN = 1
    return game_state