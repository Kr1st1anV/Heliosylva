from pyray import *
from constants import LIGHT_BROWN
import assets

def is_mob_available(level, mob_type):
    if level >= 13:
        return True
    if mob_type == "beetle" and level >= 12:
        return True
    if mob_type == "snail" and level >= 8:
        return True
    if mob_type == "dragonfly" and level >= 5:
        return True
    if mob_type == "butterfly" and level >= 3:
        return True
    return mob_type == "worm"

def display_inventory(level, mouse_x, mouse_y):
    lock_size = 0.6
    draw_texture_ex(assets.WORM[0], (932,295), 0.0, 1.0, WHITE )
    draw_text_ex(assets.DICO_FONT, "Cost: 1", (937, 337), 15, 0.0, LIGHT_BROWN)
    if level >= 3:
        draw_texture_ex(assets.BUTTERFLY[0], (1042,304), 0.0, 1.0, WHITE )
        draw_text_ex(assets.DICO_FONT, "Cost: 5", (1038, 337), 15, 0.0, LIGHT_BROWN)
    else:
        draw_texture_ex(assets.LOCK, (1038,299), 0.0, lock_size, WHITE )
        draw_text_ex(assets.DICO_FONT, "Wave: 3", (1034, 337), 15, 0.0, RED)
    if level >= 5:
        draw_texture_ex(assets.DRAGONFLY[0], (1143,304), 0.0, 1.0, WHITE )
        draw_text_ex(assets.DICO_FONT, "Cost: 10", (1136, 337), 15, 0.0, LIGHT_BROWN)
    else:
        draw_texture_ex(assets.LOCK, (1138,299), 0.0, lock_size, WHITE )
        draw_text_ex(assets.DICO_FONT, "Wave: 5", (1134, 337), 15, 0.0, RED)
    if level >= 8:
        draw_texture_ex(assets.SNAIL[0], (939,359), 0.0, 1.0, WHITE )
        draw_text_ex(assets.DICO_FONT, "Cost: 20", (932, 400), 15, 0.0, LIGHT_BROWN)
    else:
        draw_texture_ex(assets.LOCK, (938,364), 0.0, lock_size, WHITE )
        draw_text_ex(assets.DICO_FONT, "Wave: 8", (933, 403), 15, 0.0, RED)
    if level >= 12:
        draw_texture_ex(assets.BEETLE[0], (1039,359), 0.0, 1.0, WHITE )
        draw_text_ex(assets.DICO_FONT, "Cost: 50", (1035, 400.0), 15, 0.0, LIGHT_BROWN)
    else:
        draw_texture_ex(assets.LOCK, (1038,364), 0.0, lock_size, WHITE )
        draw_text_ex(assets.DICO_FONT, "Wave: 12", (1030, 403), 15, 0.0, RED)
        
    draw_texture_ex(assets.LOCK, (1138,364), 0.0, lock_size, WHITE )
    draw_text_ex(assets.DICO_FONT, "Wave: ?", (1134, 403), 15, 0.0, RED)
            
    #print((mouse_x, mouse_y))