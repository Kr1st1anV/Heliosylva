from pyray import *
import constants

def background_music(stage, music):
    """Plays Background Music During Game

    Args:
        stage (int): play, pause, or resume
        music (Music): Music file

    Returns:
        int: Returns any updated value for stage
    """
    time_played = get_music_time_played(music)
    time_length = get_music_time_length(music)
    if time_played >= time_length and time_length > 0:
            seek_music_stream(music, 0.0)
            
    if get_key_pressed() == ord("M"):
        stage += 1
        if stage == 4:
            stage = 2
            
    match stage:
        case 1:
            if not is_music_stream_playing(music):
                play_music_stream(music)
        case 2:
            pause_music_stream(music)
        case 3:
            resume_music_stream(music)
    update_music_stream(music)
    return stage

def set_volume():
    if constants.VOLUME > 9:
        set_master_volume(1)
    else:
        set_master_volume(constants.VOLUME/10)
    