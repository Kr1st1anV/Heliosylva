from pyray import *
import asyncio
import platform
import audio 
import assets
import sys
from constants import *
from game_engine import *
from start_menu import *
from end_scenes import *
import math

def restart_variables():
    return 1, 1, 0, 0, "start", 10

async def main():
    FPS = 60
    level, stage, counter, end_counter, game_state, tree_health = restart_variables()
    init_window(SCREEN_SIZE_X,SCREEN_SIZE_Y, "Heliosylva")
    
    if AUDIO_OK:
        init_audio_device()
    set_target_fps(FPS)
    # SETS ICON set_window_icon()
    #LOADING SCREEN AT START
    begin_drawing()
    clear_background(BLACK)
    draw_texture_pro(load_texture("assets/start_screen/animation/startscreen 1.png"), (0,0,460, 329),
                     (0,0,1280,720), (0,0), 0.0, WHITE)
    draw_text_ex(load_font("assets/fonts/Dico.ttf"), 
                 "ASSETS \nLOADING...", (450,300),92, 0.0, (255, 198, 98, 255))
    end_drawing()

    assets.load_assets()
    audio.set_volume()

    while not window_should_close():
        begin_drawing()
        stage = audio.background_music(stage, assets.BG_MUSIC)
        clear_background(BLACK)
        if "start" in game_state:
            level, _, _, end_counter, _, tree_health = restart_variables()
            game_state, counter = display_start_screen(game_state, counter)
            initialize_branches(level)
        elif "game" in game_state:
            game_state, level, tree_health = game(game_state, level, tree_health)
        elif "end" in game_state: 
            level, _, counter, _, _, tree_health = restart_variables()
            game_state, end_counter = end_scene(game_state, end_counter)
        #draw_fps(15,15)
        end_drawing()

        await asyncio.sleep(0)
        
    close_audio_device()
    close_window()

asyncio.run(main())