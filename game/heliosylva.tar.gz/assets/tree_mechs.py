from pyray import *
from constants import BROWN_COLOR
import assets

MAX_TREE_HEALTH = [10, 17, 25, 32, 39, 47, 54, 62, 69, 76, 84, 91, 98, 106, 113, 121, 128, 135, 143, 150, 0]

def reset_tree_health(level):
    return MAX_TREE_HEALTH[level - 1]

def show_tree_health(level, tree_health):
    diff = int(10 * tree_health / MAX_TREE_HEALTH[level - 1])
    if tree_health > 0 and diff == 0:
        diff = 1
    draw_texture_ex(assets.HEALTH_BAR_UI[diff], (70,590), 0, 0.85, WHITE)
    length_offset = 397
    temp = MAX_TREE_HEALTH[level - 1]
    zero_count = 0
    while temp > 0:
        if temp // 10 > 0:
            zero_count += 1
        temp //= 10
    match zero_count:
        case 2:
            length_offset = 385
        case 3:
            length_offset = 372
    
    draw_text_ex(assets.DICO_FONT, str(tree_health) + " / "+ str(MAX_TREE_HEALTH[level - 1]), (length_offset,632), 30, 0.0, BROWN_COLOR)