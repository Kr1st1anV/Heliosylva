from pyray import *
import constants
from audio import set_volume
import assets

def display_settings(game_state):
    global pt0, pt1, pt2
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    exit_rect = (440,105,38, 38)
    instructions_rect = (460, 300, 205, 40)
    surrender_rect = (519, 542, 243, 49)
    vol_down_rect = (670, 235, 32, 38)
    vol_up_rect = (786, 235, 32, 38)
    credits_rect = (405, 425, 160, 55)
    draw_rectangle_rec((0,0,constants.SCREEN_SIZE_X, constants.SCREEN_SIZE_Y), fade(GRAY, 0.3))
    if "surrender" in game_state:
        game_state = display_surrender(game_state)
    elif "instructions" in game_state:
        game_state = display_instructions(game_state)
    else:
        if "cave" in game_state:
            draw_texture_ex(assets.CAVE_SETTINGS, (361,18), 0.0, 0.8, WHITE)
        elif "island" in game_state:
            draw_texture_ex(assets.ISLAND_SETTINGS, (370, 25), 0.0, 0.8, WHITE)
        if check_collision_point_rec((mouse_x, mouse_y), exit_rect) and is_mouse_button_pressed(0):
            if constants.AUDIO_OK:
                play_sound(assets.CLICK_SOUND)
            game_state = "game"
        elif check_collision_point_rec((mouse_x, mouse_y), instructions_rect) and is_mouse_button_pressed(0):
                if constants.AUDIO_OK:
                    play_sound(assets.CLICK_SOUND)
                if "cave" in game_state:
                    game_state = "game_cave_instructions"
                elif "island" in game_state:
                    game_state = "game_island_instructions"
        elif check_collision_point_rec((mouse_x, mouse_y), surrender_rect) and is_mouse_button_pressed(0):
                if constants.AUDIO_OK:
                    play_sound(assets.CLICK_SOUND)
                if "cave" in game_state:
                    game_state = "game_cave_surrender"
                elif "island" in game_state:
                    game_state = "game_island_surrender"
        elif check_collision_point_rec((mouse_x, mouse_y), vol_down_rect) and is_mouse_button_pressed(0):
                    if constants.AUDIO_OK:
                        play_sound(assets.CLICK_SOUND)
                    if constants.VOLUME > 0:
                        constants.VOLUME -= 1
                    set_volume()
        elif check_collision_point_rec((mouse_x, mouse_y), vol_up_rect) and is_mouse_button_pressed(0):
                    if constants.AUDIO_OK:
                        play_sound(assets.CLICK_SOUND)
                    if constants.VOLUME < 10:
                        constants.VOLUME += 1
                    set_volume()
        position = (737,239)
        if constants.VOLUME == 10:
            position = (730,239)
        draw_text_ex(assets.DICO_FONT, str(constants.VOLUME), position, 45, 0.0, constants.BROWN_COLOR)
    return game_state

def display_instructions(game_state):
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    if "cave" in game_state:
        draw_texture_ex(assets.CAVE_INSTR, (370, 25), 0.0, 0.8, WHITE)
    elif "island" in game_state:
        draw_texture_ex(assets.ISLAND_INSTR, (370, 25), 0.0, 0.8, WHITE)
    exit_rect = (440,105,38, 38)
    if check_collision_point_rec((mouse_x, mouse_y), exit_rect) and is_mouse_button_pressed(0):
        if constants.AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game_island_settings"
    return game_state

def display_surrender(game_state):
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    exit_rect = (375, 220, 40, 40)
    back_2_game_rect = (460, 405, 70, 50)
    quit_rect = (715, 405, 100, 50)
    if "island" in game_state:
        draw_texture_ex(assets.ISLAND_SURRENDER, (295, 148), 0.0, 1.0, WHITE)
        if check_collision_point_rec((mouse_x, mouse_y), exit_rect) and is_mouse_button_pressed(0):
            if constants.AUDIO_OK:
                play_sound(assets.CLICK_SOUND)
            game_state = "game_island_settings"
    elif "cave" in game_state:
            draw_texture_ex(assets.CAVE_SURRENDER, (295, 148), 0.0, 1.0, WHITE)
            if check_collision_point_rec((mouse_x, mouse_y), exit_rect) and is_mouse_button_pressed(0):
                if constants.AUDIO_OK:
                    play_sound(assets.CLICK_SOUND)
                game_state = "game_cave_settings"
    if check_collision_point_rec((mouse_x, mouse_y), back_2_game_rect) and is_mouse_button_pressed(0):
        if constants.AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "game"
    elif check_collision_point_rec((mouse_x, mouse_y), quit_rect) and is_mouse_button_pressed(0):
        if constants.AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "start"
    return game_state