from pyray import *
from tile_system import *
from constants import *
from tile_system import *
from entities import Entities
from game_settings import display_settings
from sprite_stats import *
from tree_mechs import show_tree_health, reset_tree_health
import assets
from cloud_animation import *
from unlocked_mobs import *

MAX_BRANCHES = [20, 30, 40, 45, 55, 65, 75, 80, 90, 100, 110, 115, 125, 135, 145, 150, 160, 170, 180, 190, 0]
BRANCHES = 10
BUILD_COOLDOWN = 2
EDITING = 1
PREV_EDITING = EDITING
CURR_STATE = 1
PATH = []
DEFENSES = []
MOBS = []
CURSOR_ANIMATION_COUNT = 0
BUILD_OR_REMOVE_PATH = 0
HIDE_TOWERS = False

SETTINGS_RECT = (1106.0, 656.0, 132.0, 33.0)
BOOK_BTN_RECT = (910, 525, 300, 70)
SCROLLS_BTN_RECT = (910, 453, 300, 70)

def initialize_branches(level):
    global BRANCHES
    BRANCHES = MAX_BRANCHES[level-1]
    
def reset_game():
    global BRANCHES, ROUND_TIME, MOBS, BUILD_COOLDOWN, PREV_EDITING, CURR_STATE, PATH, DEFENSES
    BRANCHES = 10
    ROUND_TIME = 60
    MOBS = []
    BUILD_COOLDOWN = 2
    EDITING = 1
    PREV_EDITING = EDITING
    CURR_STATE = 1
    PATH = []
    DEFENSES = []
    constants.initial_clouds = True
    constants.CLOUDS = []
    show_cursor()

def game(game_status, level, tree_health):
    global BRANCHES, MOBS, MAX_BRANCHES, EDITING, BUILD_COOLDOWN, PATH, ROUND_TIME, PREV_EDITING
    global CURSOR_ANIMATION_COUNT, BUILD_OR_REMOVE_PATH, HIDE_TOWERS
    if ROUND_TIME <= 0:
        tree_health = 10
        level = 1
        game_status = "end_loss"
        reset_game()
        return game_status, level, tree_health
    if level > 20:
        show_cursor()
        game_status = "end_win"
    mouse_pos = get_mouse_position()
    if game_status == "game" and check_collision_point_rec((mouse_pos.x, mouse_pos.y), SETTINGS_RECT) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_status = "game_island_settings"
        PREV_EDITING = EDITING
    if game_status == "game" and check_collision_point_rec((mouse_pos.x, mouse_pos.y), BOOK_BTN_RECT) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_status = "game_island_book"
        PREV_EDITING = EDITING
    if game_status == "game" and check_collision_point_rec((mouse_pos.x, mouse_pos.y), SCROLLS_BTN_RECT) and is_mouse_button_pressed(0):
        if AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_status = "game_island_scrolls"
        PREV_EDITING = EDITING
    #SHOWS MAP
    draw_texture_pro(assets.SKY, (0,0,assets.SKY.width, assets.SKY.height),
                                        (36,36,814,644), (0,0), 0.0, WHITE)
    draw_clouds(game_status)
    draw_texture_ex(assets.ISLAND, (0,70), 0.0, 1.0, WHITE)
    draw_texture_ex(assets.CHERRYBLOSSOM, (310, 35), 0.0, 1.5, WHITE)
    draw_texture_pro(assets.ISLAND_UI, (0,0,assets.ISLAND_UI.width, assets.ISLAND_UI.height),
                                (0,0,1280,720), (0,0), 0.0, WHITE)
    DEFENSES, BUILD_OR_REMOVE_PATH = generate_board(GRID_SIZE, mouse_pos, EDITING, BUILD_COOLDOWN, BUILD_OR_REMOVE_PATH)
    # MOB MOVEMENT
    gone = []
    for mob in MOBS:
        if mob.health > 0:
            ended, tree_health = mob.move(tree_health, game_status)
            if ended:
                gone.append(mob)
        else:
            gone.append(mob)
    for mob in gone:
        MOBS.remove(mob)
    build_defense(DEFENSES, HIDE_TOWERS)
    for mob in MOBS:
        mob.draw_health()
    display_inventory(level, mouse_pos.x, mouse_pos.y)
    #CUSTOM CURSOR ANIMATION
    if 1 <= level <= 20:
        show_tree_health(level, tree_health)
    draw_text_ex(assets.DICO_FONT, "WAVE: " + str(level), (910,60), 45, 0.0, BROWN_COLOR)
    draw_text_ex(assets.DICO_FONT, ": " + str(int(ROUND_TIME)) + "s", (970,193), 45, 0.0, BROWN_COLOR)
    draw_text_ex(assets.DICO_FONT, ": " + str(BRANCHES), (960,128), 45, 0.0, BROWN_COLOR)
    if "surrender" in game_status:
        EDITING = 0
        game_status = display_settings(game_status)
        if game_status == "start":
            BRANCHES = 10
            ROUND_TIME = 60
            MOBS = []
            BUILD_COOLDOWN = 2
            EDITING = 1
            tree_health = 10
            level = 1
            PREV_EDITING = EDITING
            CURR_STATE = 1
            PATH = []
            DEFENSES = []
            constants.initial_clouds = True
            constants.CLOUDS = []
            show_cursor()
            return game_status, level, tree_health
    if ("settings" not in game_status) and ("surrender" not in game_status) and ("instructions" not in game_status):    
        if PATH:
            ROUND_TIME -= 0.01667
    if "settings" in game_status or "surrender" in game_status or "instructions" in game_status:
        EDITING = 0
        HIDE_TOWERS = False
        game_status = display_settings(game_status)
        if game_status == "game":
            BUILD_COOLDOWN = 1
    elif "book" in game_status:
        EDITING = 0
        game_status = show_book(game_status)
        if game_status == "game":
            BUILD_COOLDOWN = 1
    elif "scrolls" in game_status:
        EDITING = 0
        game_status = show_scrolls(game_status)
        if game_status == "game":
            BUILD_COOLDOWN = 1
    else:
        EDITING = PREV_EDITING
        if is_key_pressed(ord(" ")):
            PATH = find_mob_path()
            if ROUND_TIME == 60 and PATH:
                PATH = start_round()
                EDITING = 0
                PREV_EDITING = EDITING
        if tree_health <= 0:
            MOBS = []
            PATH = []
            ROUND_TIME = 60
            EDITING = 1
            PREV_EDITING = EDITING
            level += 1
            if level <= 20:
                tree_health = reset_tree_health(level)
                initialize_branches(level)
            new_board(level)
        if not EDITING and BRANCHES > 0:
            if is_key_pressed(ord("1")):
                game_engine_spawn_mob(level, "worm")
            if is_key_pressed(ord("2")):
                game_engine_spawn_mob(level, "butterfly")
            if is_key_pressed(ord("3")):
                game_engine_spawn_mob(level, "dragonfly")
            if is_key_pressed(ord("4")):
                game_engine_spawn_mob(level, "snail")
            if is_key_pressed(ord("5")):
                game_engine_spawn_mob(level, "beetle")
        HIDE_TOWERS = is_key_down(ord("V"))
        if is_key_pressed(ord("P")):
            tree_health = 0
        if is_key_pressed(ord("B")):
            if EDITING in [-1, 1]:
                EDITING = -1 if EDITING == 1 else 1
                PREV_EDITING = EDITING
                BUILD_OR_REMOVE_PATH = 0
                CURSOR_ANIMATION_COUNT = 0
        if is_key_pressed(ord("R")):
            if EDITING in [-1,1]:
                new_board(level)
        if 1 <= level <= 20:
            if check_collision_point_rec((int(mouse_pos.x), int(mouse_pos.y)), (36,36,814,644)) and EDITING == 1:
                    #set_cursor_hidden(True)
                    draw_texture(assets.HAMMER[CURSOR_ANIMATION_COUNT // 4], int(mouse_pos.x) - 30, int(mouse_pos.y) - 10, WHITE)
            elif check_collision_point_rec((int(mouse_pos.x), int(mouse_pos.y)), (36,36,814,644)) and EDITING == -1:
                    #set_cursor_hidden(True)
                    draw_texture(assets.SHOVEL[CURSOR_ANIMATION_COUNT // 4], int(mouse_pos.x) - 20, int(mouse_pos.y) - 30, WHITE)
            # else:
            #     set_cursor_hidden(False)
        #BUILD COOLDOWN
        if BUILD_COOLDOWN > 0:
            BUILD_COOLDOWN -= 0.05
        else:
            BUILD_COOLDOWN = 0
        # BUILD ANIMATIOn
        if BUILD_OR_REMOVE_PATH == 1:
            CURSOR_ANIMATION_COUNT += 1
            if BUILD_OR_REMOVE_PATH == 1 and CURSOR_ANIMATION_COUNT >= 4 * 4:
                CURSOR_ANIMATION_COUNT = 0
                BUILD_OR_REMOVE_PATH = 0
        # REMOVE ANIMATION:
        if BUILD_OR_REMOVE_PATH == -1:
            CURSOR_ANIMATION_COUNT += 1
            if BUILD_OR_REMOVE_PATH == -1 and CURSOR_ANIMATION_COUNT >= 6 * 4:
                CURSOR_ANIMATION_COUNT = 0
                BUILD_OR_REMOVE_PATH = 0
    if len(MOBS) == 0 and BRANCHES == 0 and tree_health > 0:
        tree_health = 10
        level = 1
        game_status = "end_loss"
        reset_game()
        return game_status, level, tree_health
    return game_status, level, tree_health

def game_engine_spawn_mob(level, mob_type):
    global BRANCHES, PATH, MOBS
    mob = Entities(PATH, mob_type)
    if PATH and is_mob_available(level, mob_type):
        if BRANCHES - mob.cost >= 0:
            BRANCHES = mob.buy(BRANCHES)
            if AUDIO_OK:
                play_sound(assets.ROUND_SOUND)
            MOBS.append(mob)

def start_round():
    return find_mob_path()

def set_cursor_hidden(hidden):
    if hidden:
        hide_cursor()
    else:
        show_cursor()
        