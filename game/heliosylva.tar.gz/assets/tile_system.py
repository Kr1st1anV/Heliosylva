from pyray import *
from cursor_animations import *
from constants import *
import assets
import maps
from towers import *

tower_details = {}

def new_board(level):
    global grid_layout
    # grid_layout = [[0] * GRID_SIZE for _ in range(GRID_SIZE)]
    # grid_layout[0][GRID_SIZE - 1] = "end"
    # grid_layout[GRID_SIZE - 1][0] = "start"
    # grid_layout = [[0, 0, 0, 0, "ladybug", 0, 0, 'end'], 
    #                 [0, 0, 0, 0, 0, 0, 0, "tree"], 
    #                 [0, 0, "bush", 0, 0, 0, 0, 0], 
    #                 [0, 0, 0, 0, 0, 0, 0, 0], 
    #                 [0, "tree", 0, 0, 0, "bee", 0, 0], 
    #                 [0, 0, 0, 0, 0, 0, 0, 0], 
    #                 [0, 0, 0, 0, 0, 0, 0, 0], 
    #                 ['start', "bush", 0, 0, 0, 0, 0, 0]]
    if level > 20:
        return grid_layout
    else:
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                grid_layout[i][j] = maps.LEVELS[level][i][j]
    return grid_layout

def find_mob_path():
    q = []
    q.append((GRID_SIZE - 1,0))
    
    visited = [False] * GRID_SIZE ** 2
    visited[(GRID_SIZE - 1) * GRID_SIZE + 0] = True
    
    prev = [None] * GRID_SIZE ** 2
    
    while q:
        node = q[0]
        q = q[1:]
        neighbors = find_neighbors(node[0], node[1])
        
        for next in neighbors:
            if grid_layout[next[0]][next[1]] == "end":
                visited[next[0] * GRID_SIZE + next[1]] = True
                prev[next[0] * GRID_SIZE + next[1]] = node
                q = []
            if not visited[next[0] * GRID_SIZE + next[1]]:
                q.append(next)
                visited[next[0] * GRID_SIZE + next[1]] = True
                prev[next[0] * GRID_SIZE + next[1]] = node
    return reconstruct_path(prev)

def reconstruct_path(prev):
    path = []
    at = (0,GRID_SIZE - 1)
    while at != None:
        path.append(at)
        at = prev[at[0] * GRID_SIZE + at[1]]
    path.reverse()
    if path[0] == (GRID_SIZE - 1,0):
        return path
    return []

def find_neighbors(r, c):
    
    neighbors = []
    dc = [-1, 1, 0, 0]
    dr = [0,0, -1, 1]
    
    for i in range(4):
        rr = r + dr[i]
        cc = c + dc[i]
        
        if rr < 0 or cc < 0: continue
        if rr >= GRID_SIZE or cc >= GRID_SIZE: continue
        
        if grid_layout[rr][cc] == 1 or grid_layout[rr][cc] == "end":
            neighbors.append((rr,cc))
    return neighbors

def generate_board(GRID_SIZE, mouse_pos, editing, build_cooldown, build_or_remove_path):
    global tower_details
    defenses = []
    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            tile = ""
            highlight = fade(WHITE, 0.0)
            if grid_layout[i][j] == 0:
                if editing == -1:
                    continue
                tile = assets.PATHS[(0,0,0,0)]
            elif grid_layout[i][j] == 1:
                highlight = WHITE
                # (R, D, L, U)
                tile = determine_tile_texture(i,j)
            elif grid_layout[i][j] == "start" or grid_layout[i][j] == "end":
                highlight = WHITE
                tile = determine_spawn_texture(i,j)
            elif grid_layout[i][j] in ["bee", "tree", "ladybug", "bush"]:
                highlight = WHITE
                if (i,j) not in tower_details and grid_layout[i][j] in ["bee", "ladybug"]:
                    tower_details[(i,j)] = Tower(grid_layout[i][j], (i,j))
                defenses.append((i,j))
                tile = assets.SHADOW_TILE
            if editing in [-1, 1]:
                if is_mouse_over_isometric_tile(mouse_pos, center_x=(GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) + TILE_WIDTH // 2), center_y=(GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) + TILE_HEIGHT // 4), width=TILE_WIDTH, height=TILE_HEIGHT):
                    highlight = fade(WHITE, 0.7)
                    if is_mouse_button_down(0) :
                        if grid_layout[i][j] == 0 and build_cooldown == 0 and editing == 1:
                            grid_layout[i][j] = 1
                            build_or_remove_path = 1
                        if grid_layout[i][j] == 1 and build_cooldown == 0 and editing == -1:
                            grid_layout[i][j] = 0
                            build_or_remove_path = 1
            draw_texture_ex(tile, (GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2)), 0.0, SCALE, highlight)
    return defenses, build_or_remove_path
                      
def is_mouse_over_isometric_tile(mouse_pos, center_x, center_y, width, height):
    # Calculate distance from mouse to tile center
    dx = abs(mouse_pos.x - center_x)
    dy = abs(mouse_pos.y - center_y)
    return (dx / (width / 2.0)) + (dy / (height / 2.0)) <= 1.0

def determine_tile_texture(r, c):
    neighbors = []
    dx = [1, 0, -1, 0]
    dy = [0, 1, 0, -1]
    for i in range(4):
        rr = r + dy[i]
        cc = c + dx[i]
        if cc < 0 or rr < 0:
            neighbors.append(0)
            continue
        elif cc >= GRID_SIZE or rr >= GRID_SIZE:
            neighbors.append(0)
            continue
        elif grid_layout[rr][cc] in [1, "end", "start"]:
            neighbors.append(1)
        else:
            neighbors.append(0)
    return assets.PATHS[tuple(neighbors)]

def determine_spawn_texture(r, c):
    direction = [0] * 4
    dx = [1, 0, -1, 0]
    dy = [0, 1, 0, -1]
    for i in range(4):
        rr = r + dy[i]
        cc = c + dx[i]
        if cc < 0 or rr < 0: continue
        elif cc >= GRID_SIZE or rr >= GRID_SIZE: continue
        elif grid_layout[rr][cc] == 1:
            direction[i] = 1
            break
    return assets.SPAWNS_ISLAND[tuple(direction)]

def build_defense(defenses, hide_towers):
    global tower_details
    # use dict to store towers
    for i,j in defenses:
        if grid_layout[i][j] == "bee":
            if not hide_towers:
                if tower_details[(i,j)].state == "idle":
                    draw_texture_pro(assets.BEE_IDLE[tower_details[(i,j)].animation//10], 
                                    (0,0, tower_details[(i,j)].look_to * assets.BEE_IDLE[tower_details[(i,j)].animation//10].width, assets.BEE_IDLE[tower_details[(i,j)].animation//10].height),
                                    (GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) - 70, 
                                    assets.BEE_IDLE[tower_details[(i,j)].animation//10].width * SCALE, assets.BEE_IDLE[tower_details[(i,j)].animation//10].height * SCALE),
                                    (0,0), 
                                    0.0,
                                    WHITE)
                elif tower_details[(i,j)].state == "attack":
                    draw_texture_pro(assets.BEE_ATK[tower_details[(i,j)].animation//5], 
                                    (0,0, tower_details[(i,j)].look_to * assets.BEE_ATK[tower_details[(i,j)].animation//5].width, assets.BEE_ATK[tower_details[(i,j)].animation//5].height),
                                    (GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) - 70, 
                                    assets.BEE_ATK[tower_details[(i,j)].animation//5].width * SCALE, assets.BEE_ATK[tower_details[(i,j)].animation//5].height * SCALE),
                                    (0,0), 
                                    0.0,
                                    WHITE)
            tower_details[(i,j)].attack()
        elif grid_layout[i][j] == "ladybug":
            if not hide_towers:
                if tower_details[(i,j)].state == "idle":
                    draw_texture_pro(assets.LADYBUG_IDLE[tower_details[(i,j)].animation//10], 
                                    (0,0, tower_details[(i,j)].look_to * assets.LADYBUG_IDLE[tower_details[(i,j)].animation//10].width, assets.LADYBUG_IDLE[tower_details[(i,j)].animation//10].height),
                                    (-10 + GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) - 40, 
                                    assets.LADYBUG_IDLE[tower_details[(i,j)].animation//10].width * SCALE * 0.95, assets.LADYBUG_IDLE[tower_details[(i,j)].animation//10].height * SCALE* 0.95),
                                    (0,0), 
                                    0.0,
                                    WHITE)
                elif tower_details[(i,j)].state == "attack":
                    draw_texture_pro(assets.LADYBUG_ATK[tower_details[(i,j)].animation//5], 
                                    (0,0, tower_details[(i,j)].look_to * assets.LADYBUG_ATK[tower_details[(i,j)].animation//5].width, assets.LADYBUG_ATK[tower_details[(i,j)].animation//5].height),
                                    (-10 + GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) - 40, 
                                    assets.LADYBUG_ATK[tower_details[(i,j)].animation//5].width * SCALE * 0.95, assets.LADYBUG_ATK[tower_details[(i,j)].animation//5].height * SCALE * 0.95),
                                    (0,0), 
                                    0.0,
                                    WHITE)
            tower_details[(i,j)].attack()
        elif grid_layout[i][j] == "bush":
            if not hide_towers:
                draw_texture_ex(assets.BUSH, (0 +  GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) - 20), 0.0, SCALE, WHITE)
        elif grid_layout[i][j] == "tree":
            if not hide_towers:
                draw_texture_ex(assets.TREE, (-28 +  GRID_X + (j * TILE_WIDTH // 2) + (i * TILE_WIDTH // 2) ,GRID_Y - (j * TILE_HEIGHT * 1/2) + (i * TILE_HEIGHT // 2) - 80), 0.0, SCALE * 2, WHITE)