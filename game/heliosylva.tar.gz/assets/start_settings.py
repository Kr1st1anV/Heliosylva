from pyray import *
import constants
from audio import set_volume
from tile_system import new_board
import assets

pt1 = ()
pt2 = ()

def display_settings(game_state):
    global pt1, pt2
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    #start_rect = (59 + 90, 214 + 60, 304,130)
    exit_rect = (385, 145, 37, 37)
    instructions_rect = (405, 340, 255, 56)
    vol_down_rect = (660, 260, 45, 45)
    vol_up_rect = (810, 260, 45, 45)
    credits_rect = (405, 425, 160, 55)
    #draw_rectangle_rec(start_rect, BLUE) #debug purposws
    # draw_texture_ex(assets.SETTINGS, (59, 214), 0.0, 1.0, WHITE)
    draw_rectangle_rec((0,0,constants.SCREEN_SIZE_X, constants.SCREEN_SIZE_Y), fade(GRAY, 0.3))
    draw_texture_ex(assets.SETTINGS, (291,38), 0.0, 1.0, WHITE)
    #draw_rectangle_rec(settings_rect, RED)
    # draw_texture_ex(assets.SETTINGS_BUTTON, (1045 - 65, 615 - 50), 0.0, 1.0, WHITE)
    if check_collision_point_rec((mouse_x, mouse_y), exit_rect) and is_mouse_button_pressed(0):
        if constants.AUDIO_OK:
            play_sound(assets.CLICK_SOUND)
        game_state = "start"
    elif check_collision_point_rec((mouse_x, mouse_y), instructions_rect) and is_mouse_button_pressed(0):
            if constants.AUDIO_OK:
                play_sound(assets.CLICK_SOUND)
            game_state = "start_instructions"
    elif check_collision_point_rec((mouse_x, mouse_y), vol_down_rect) and is_mouse_button_pressed(0):
                if constants.AUDIO_OK:
                    play_sound(assets.CLICK_SOUND)
                if constants.VOLUME > 0:
                    constants.VOLUME -= 1
                set_volume()
    elif check_collision_point_rec((mouse_x, mouse_y), vol_up_rect) and is_mouse_button_pressed(0):
                if constants.AUDIO_OK:
                    play_sound(assets.CLICK_SOUND)
                if constants.VOLUME < 10:
                    constants.VOLUME += 1
                set_volume()
    position = (750 ,267)
    if constants.VOLUME == 10:
        position = (746 ,267)
    draw_text_ex(assets.DICO_FONT, str(constants.VOLUME), position, 45, 0.0, constants.BROWN_COLOR)
    return game_state

def display_instructions(game_state):
    global pt1, pt2
    mouse_x = get_mouse_x()
    mouse_y = get_mouse_y()
    draw_rectangle_rec((0,0,constants.SCREEN_SIZE_X, constants.SCREEN_SIZE_Y), fade(GRAY, 0.3))
    draw_texture_ex(assets.ISLAND_INSTR, (370, 25), 0.0, 0.8, WHITE)
    exit_rect = (440,105,38, 38)
    if check_collision_point_rec((mouse_x, mouse_y), exit_rect) and is_mouse_button_pressed(0):
            if constants.AUDIO_OK:
                play_sound(assets.CLICK_SOUND)
            game_state = "start_settings"
    return game_state