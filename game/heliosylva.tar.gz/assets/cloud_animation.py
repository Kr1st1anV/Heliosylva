from pyray import *
import random
import constants
import assets

class Cloud():
    def __init__(self, init_clouds):
        self.speed = 0.2 + 0.3 * random.random()
        self.pos = ((0 if constants.initial_clouds else -400) + 1000 * random.random() * init_clouds, 
                    -50 + 110 * (1 if random.random() > 0.5 else 0))
        self.cloud = 2 if random.random() > 0.5 else 1
        
    def move(self, game_status):
        self.pos = (self.pos[0] + self.speed * (0 if "settings" in game_status or "surrender" in game_status or "instructions" in game_status else 1), 
                    self.pos[1])
        if self.cloud == 1:
            draw_texture_ex(assets.CLOUD1, self.pos, 0, 1.0, WHITE)
        if self.cloud == 2:
            draw_texture_ex(assets.CLOUD2, self.pos, 0, 1.0, WHITE)

def draw_clouds(game_status):
    if len(constants.CLOUDS) < 5:
        constants.CLOUDS.append(Cloud(1 if constants.initial_clouds else 0))
    for cloud in constants.CLOUDS[:]:
        cloud.move(game_status)
        if cloud.pos[0] > 900:
            constants.initial_clouds = False
            constants.CLOUDS.remove(cloud)
    