from pyray import *

def load_assets():
    # BOOKS
    global BOOK1, BOOK2
    BOOK1 = load_texture("assets/books/map1/book1.png")
    BOOK2 = load_texture("assets/books/map2/book2.png")
    # CLOUDS
    global CLOUD1, CLOUD2
    CLOUD1 = load_texture("assets/clouds/cloud1.png")
    CLOUD2 = load_texture("assets/clouds/cloud2.png")
    # CURSOR
    global HAMMER, SHOVEL
    HAMMER = [load_texture("assets/cursor/hammer/a" + str(i) + ".png") for i in range(1,5)]
    SHOVEL = [load_texture("assets/cursor/shovel/shovel" + str(i) + ".png") for i in range(1,7)]
    # END_ANIMATION
    global VICTORY, DEFEAT
    VICTORY = [load_texture("assets/end_animation/win/f" + str(i) + ".png") for i in range(1,34)] 
    DEFEAT = [load_texture("assets/end_animation/loss/e" + str(i) + ".png") for i in range(1,28)] 
    
    # ENTITIES
    global BEETLE, BUTTERFLY, DRAGONFLY, SNAIL, WORM
    BEETLE = [load_texture("assets/entities/beetle/beetle_000" + str(i) + ".png") for i in range(1,5)]
    BUTTERFLY = [load_texture("assets/entities/butterfly/butterfly_000" + str(i) + ".png") for i in range(1,5)]
    DRAGONFLY = [load_texture("assets/entities/dragonfly/dragonfly_000" + str(i) + ".png") for i in range(1,5)]
    SNAIL = [load_texture("assets/entities/snail/snail_000" + str(i) + ".png") for i in range(1,5)]
    WORM = [load_texture("assets/entities/worm/worm_000" + str(i) + ".png") for i in range(1,5)]
    # FONTS
    global DICO_FONT
    DICO_FONT = load_font("assets/fonts/Dico.ttf")
    
    # HEALTH_BAR
    global HEALTH_BAR_UI
    HEALTH_BAR_UI = [load_texture("assets/health_bar/hb" + str(i * 10) + ".png") for i in range(11)]
    # MUSIC
    global CLICK_SOUND, BG_MUSIC, ROUND_SOUND
    CLICK_SOUND = load_sound("assets/music/button1.ogg")
    ROUND_SOUND = load_sound("assets/music/button2.ogg")
    BG_MUSIC = load_music_stream("assets/music/background_music.ogg")
    
    # PATHS
    global SHADOW_TILE, PATH, PATHS
    SHADOW_TILE = load_texture("assets/paths/map2/shadowtile.png")
    PATHS = {}
    # (Right: tr, Down: br, Left: bl, Up: tl)
    
    PATHS[(0,0,0,1)] = load_texture("assets/paths/map2/endbr.png")
    PATHS[(0,0,1,0)] = load_texture("assets/paths/map2/endtr.png")
    PATHS[(0,1,0,0)] = load_texture("assets/paths/map2/endtl.png")
    PATHS[(1,0,0,0)] = load_texture("assets/paths/map2/endbl.png")
    
    PATHS[(0,1,0,1)] = load_texture("assets/paths/map2/negdia.png")
    PATHS[(1,0,1,0)] = load_texture("assets/paths/map2/posdia.png")
    
    PATHS[(0,1,1,0)] = load_texture("assets/paths/map2/blbr.png")
    PATHS[(0,0,1,1)] = load_texture("assets/paths/map2/tlbl.png")
    PATHS[(1,0,0,1)] = load_texture("assets/paths/map2/tltr.png")
    PATHS[(1,1,0,0)] = load_texture("assets/paths/map2/trbr.png")
    
    PATHS[(0,1,1,1)] = load_texture("assets/paths/map2/3waybl.png")
    PATHS[(1,0,1,1)] = load_texture("assets/paths/map2/3waytl.png")
    PATHS[(1,1,0,1)] = load_texture("assets/paths/map2/3waytr.png")
    PATHS[(1,1,1,0)] = load_texture("assets/paths/map2/3waybr.png")
    
    PATHS[(1,1,1,1)] = load_texture("assets/paths/map2/4way.png")
    PATHS[(0,0,0,0)] = load_texture("assets/paths/map2/single.png")
    
    # SCROLLS
    global ISLAND_SCROLLS
    ISLAND_SCROLLS = []
    ISLAND_SCROLLS.append(load_texture("assets/scrolls/scroll" + "worm.png"))
    ISLAND_SCROLLS.append(load_texture("assets/scrolls/scroll" + "butterfly.png"))
    ISLAND_SCROLLS.append(load_texture("assets/scrolls/scroll" + "dragonfly.png"))
    ISLAND_SCROLLS.append(load_texture("assets/scrolls/scroll" + "snail.png"))
    ISLAND_SCROLLS.append(load_texture("assets/scrolls/scroll" + "beetle.png"))
    
    
    # SETTINGS
    global CAVE_SURRENDER, CAVE_SETTINGS, CAVE_INSTR, ISLAND_INSTR, ISLAND_SURRENDER, ISLAND_SETTINGS, SETTINGS
    CAVE_SURRENDER = load_texture("assets/settings/map1/cave_surrender.png")
    CAVE_SETTINGS = load_texture("assets/settings/map1/cave_settings.png")
    CAVE_INSTR = load_texture("assets/settings/map1/cave_instructions.png")
    ISLAND_INSTR = load_texture("assets/settings/map2/island_instructions.png")
    ISLAND_SURRENDER = load_texture("assets/settings/map2/island_surrender.png")
    ISLAND_SETTINGS = load_texture("assets/settings/map2/island_settings.png")
    SETTINGS = load_texture("assets/settings/main.png")
    
    # SPAWN
    global SPAWN_CAVE_BL, SPAWN_CAVE_BR, SPAWN_CAVE_TL, SPAWN_CAVE_TR, SPAWN_CAVE_SINGLE
    global SPAWNS_ISLAND
    SPAWNS_ISLAND = {}
    SPAWN_CAVE_BL = load_texture("assets/spawn/map1/spawnbl.png")
    SPAWN_CAVE_TL = load_texture("assets/spawn/map1/spawntl.png")
    SPAWN_CAVE_BR = load_texture("assets/spawn/map1/spawnbr.png")
    SPAWN_CAVE_TR = load_texture("assets/spawn/map1/spawntr.png")
    SPAWN_CAVE_SINGLE = load_texture("assets/spawn/map1/spawnsingle.png")
    
    SPAWNS_ISLAND[(0,1,0,0)] = load_texture("assets/spawn/map2/spawntl.png")
    SPAWNS_ISLAND[(1,0,0,0)] = load_texture("assets/spawn/map2/spawnbl.png")
    SPAWNS_ISLAND[(0,0,0,1)] = load_texture("assets/spawn/map2/spawnbr.png")
    SPAWNS_ISLAND[(0,0,1,0)] = load_texture("assets/spawn/map2/spawntr.png")
    SPAWNS_ISLAND[(0,0,0,0)] = load_texture("assets/spawn/map2/spawnsingle.png")
    
    # START_SCREEN
    global START_BG, FLAME, LOGO, SETTINGS_BUTTON, START, TUTORIAL
    START_BG = [load_texture("assets/start_screen/animation/startscreen " + str(i) + ".png") for i in range(1,21)] 
    FLAME = [load_texture("assets/start_screen/flame/flame" + str(i) + ".png") for i in range(1,5)] 
    LOGO = load_texture("assets/start_screen/logo.png")
    SETTINGS_BUTTON = load_texture("assets/start_screen/settings.png")
    START = load_texture("assets/start_screen/start.png")
    TUTORIAL = load_texture("assets/start_screen/tutorial.png")
    
    # STORE
    global LOCK, QUEST_MARK
    LOCK = load_texture("assets/store/lock.png")
    QUEST_MARK = load_texture("assets/store/questionmark.png")
    
    # TOWERS
    global BEE_IDLE, BEE_ATK, BUSH, LADYBUG_IDLE, LADYBUG_ATK, TREE
    BUSH = load_texture("assets/towers/map2/bush/bush.png")
    TREE = load_texture("assets/towers/map2/tree/tree.png")
    BEE_IDLE = [load_texture("assets/towers/map2/bee/beeidle" + str(i) + ".png") for i in range(1,5)] 
    BEE_ATK = [load_texture("assets/towers/map2/bee/beeattacking" + str(i) + ".png") for i in range(1,5)] 
    LADYBUG_IDLE = [load_texture("assets/towers/map2/ladybug/ladybugidle" + str(i) + ".png") for i in range(1,5)] 
    LADYBUG_ATK = [load_texture("assets/towers/map2/ladybug/ladybugattack" + str(i) + ".png") for i in range(1,7)] 
    
    # TREES
    global WILLOWTREE, DAM_WILLOWTREE, DEAD_WILLOWTREE, CHERRYBLOSSOM, DAM_CHERRYBLOSSOM, DEAD_CHERRYBLOSSOM
    WILLOWTREE = load_texture("assets/trees/willowtree.png")
    DAM_WILLOWTREE = load_texture("assets/trees/damaged_willowtree.png")
    DEAD_WILLOWTREE = load_texture("assets/trees/dead_willowtree.png")
    CHERRYBLOSSOM = load_texture("assets/trees/tree.png")
    DAM_CHERRYBLOSSOM = load_texture("assets/trees/damaged_tree.png")
    DEAD_CHERRYBLOSSOM = load_texture("assets/trees/dead_tree.png")
    
    # UI
    global CAVE_UI, CAVE, ISLAND_UI, SKY, ISLAND
    CAVE_UI = load_texture("assets/UI/cave_play.png")
    CAVE = load_texture("assets/UI/cave.png")
    ISLAND_UI = load_texture("assets/UI/island_play.png")
    SKY = load_texture("assets/UI/sky.png")
    ISLAND = load_texture("assets/UI/island.png")